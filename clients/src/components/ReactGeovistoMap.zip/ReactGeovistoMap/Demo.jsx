// React
import React, { Component } from "react"


// React-Geovisto
import ReactGeovistoMap from './ReactGeovistoMap'

import "./demo.scss"
import {GeovistoTilesLayerTool} from "geovisto-layer-tiles"
import { GeovistoSidebarTool } from 'geovisto-sidebar';
import 'geovisto-sidebar/dist/index.css';
import { GeovistoDrawingLayerTool } from 'geovisto-layer-drawing'
import 'geovisto-layer-drawing/dist/index.css';
// Geovisto Tools
import { CodeBlock, dracula } from "react-code-blocks";

import { Geovisto } from "geovisto"

/* example of screen component with grid layout and card wrapper usage */

const C_ID_select_data = "leaflet-combined-map-select-data"
const C_ID_check_data = "leaflet-combined-map-check-data"
const C_ID_input_data = "leaflet-combined-map-input-data"
const C_ID_check_config = "leaflet-combined-map-check-config"
const C_ID_input_config = "leaflet-combined-map-input-config"
const C_ID_input_import = "leaflet-combined-map-input-import"
const C_ID_input_export = "leaflet-combined-map-input-export"
const C_ID_get_geojson = "leaflet-combined-map-get-geojson"


export class Demo extends Component {
  constructor(props) {
    super(props)
    

    // initialize geo objects
    this.polygons = require("../../static/geo/country_polygons.json")
    this.centroids = require("../../static/geo/country_centroids.json")
    this.polygons2 = require("../../static/geo/czech_districts_polygons.json")
    this.centroids2 = require("../../static/geo/czech_districts_centroids.json")
    this.hierarchyPolygons = require("../../static/geo/geo-hierarchy_covidData.json")
    this.hierarchyPoints = require("../../static/geo/geo-hierarchy_covidDataPoint.json")
    this.hierarchyConnection = require("../../static/geo/geo-hierarchy_connection.json")

    // initialize info objects
    this.infodata = require("../../static/info/test.md")
    this.infodata2 = require("../../static/info/test2.md")

    // data and config can be changed
    this.state = {
      // implicit data
      // implicit config
      config: require("../../static/config/config.json")
    }

    // reference to the rendered map
    this.map = React.createRef()
  }


  componentDidMount() {
    // ------ enable check boxes ------ //

    const enableInput = function(checked, id) {
      if (checked) {
        document.getElementById(id)?.removeAttribute("disabled")
      } else {
        document.getElementById(id)?.setAttribute("disabled", "disabled")
      }
    }

    // enable data check box
    const enableDataInput = function(e) {
      enableInput(e.target.checked, C_ID_input_data)
    }
    document
      .getElementById(C_ID_input_data)
      ?.setAttribute("disabled", "disabled")
    document
      .getElementById(C_ID_check_data)
      ?.addEventListener("change", enableDataInput)

    // enable config check box
    const enableConfigInput = function(e) {
      enableInput(e.target.checked, C_ID_input_config)
    }
    document
      .getElementById(C_ID_input_config)
      ?.setAttribute("disabled", "disabled")
    document
      .getElementById(C_ID_check_config)
      ?.addEventListener("change", enableConfigInput)
    // ------ process files ------ //

    // process path
    const pathSubmitted = function(file, result) {
      const reader = new FileReader()
      const onLoadAction = function(e) {
        try {
          console.log(e)
          //console.log(reader.result);
          if (typeof reader.result == "string") {
            result.json = JSON.parse(reader.result)
          }
        } catch (ex) {
          console.log("unable to read file")
          console.log(ex)
          // TODO: notify user
        }
      }
      reader.onload = onLoadAction
      reader.readAsText(file)
    }

    // process data path
    const data = {
      json: undefined
    }
    const dataPathSubmitted = function() {
      console.log(this.files)
      if (this.files) {
        pathSubmitted(this.files[0], data)
      }
    }
    document
      .getElementById(C_ID_input_data)
      ?.addEventListener("change", dataPathSubmitted, false)

    // process config path
    const config = {
      json: undefined
    }
    const configPathSubmitted = function() {
      console.log(this.files)
      if (this.files) {
        pathSubmitted(this.files[0], config)
      }
    }
    document
      .getElementById(C_ID_input_config)
      ?.addEventListener("change", configPathSubmitted, false)

    // ------ import ------ //

    // import action
    const importAction = e => {
      console.log(e)
      console.log("data: ", data)
      console.log("config: ", config)

      // process data json
      if (
        !document.getElementById(C_ID_check_data).checked ||
        data.json == undefined
      ) {
        const fileName = document.getElementById(C_ID_select_data).value
        console.log(fileName)
        data.json = require("../../static/data/" + fileName)
      }

      // process config json
      if (
        !document.getElementById(C_ID_check_config).checked ||
        config.json == undefined
      ) {
        config.json = require("../../static/config/config.json")
      }

      // update state
      this.setState({
        data: data.json,
        config: config.json
      })
    }
    document
      .getElementById(C_ID_input_import)
      ?.addEventListener("click", importAction)

    // ------ export ------ //

    // get geojson after click on button

    const getGeoJson = () => {
      console.log(this.map, "map")
      const geoJSON = this.map.current.m.getState().getTools().getById("geovisto-tool-layer-drawing").getState().serializeToGeoJSON();
      const geoJSONString = JSON.stringify(geoJSON);
      console.log("geojson:", geoJSON);
      console.log("hereaa")
      return geoJSONString;
    }
    
    const pressGeo = document.getElementById(C_ID_get_geojson);
    
    if (pressGeo) {
      pressGeo.addEventListener('click', getGeoJson);
    }

    // export action
    const exportAction = e => {
      console.log(e)

      // export map configuration
      const config = JSON.stringify(
        this.map.current?.getMap().export(),
        null,
        2
      )

      // download file
      const element = document.createElement("a")
      element.setAttribute(
        "href",
        "data:text/plain;charset=utf-8," + encodeURIComponent(config)
      )
      element.setAttribute("download", "config.json")
      element.style.display = "none"
      document.body.appendChild(element)
      element.click()
      document.body.removeChild(element)

      console.log("rendered map:")
    }
    document
      .getElementById(C_ID_input_export)
      ?.addEventListener("click", exportAction)
  }

  render() {
    console.log("rendering...")
    return (
      <div className="demo-container">
        <div className="demo-toolbar">

          <input id={C_ID_input_import} type="submit" value="import" />
          <input id={C_ID_input_export} type="submit" value="export" />
          <input id={C_ID_get_geojson} type="submit" value="get" />
        </div>
        <div className="demo-map">
        <CodeBlock
          text={this.getGeoJson()}
          language="json"
          showLineNumbers
          theme={dracula}
        />
          <ReactGeovistoMap
            ref={this.map}
            id="my-geovisto-map"
            data={Geovisto.getMapDataManagerFactory().json(this.state.data)}
            geoData={Geovisto.getGeoDataManager([
              Geovisto.getGeoDataFactory().geojson(
                "world polygons",
                this.polygons
              ),
              Geovisto.getGeoDataFactory().geojson(
                "world centroids",
                this.centroids
              ),
              Geovisto.getGeoDataFactory().geojson(
                "czech polygons",
                this.polygons2
              ),
              Geovisto.getGeoDataFactory().geojson(
                "Hierarchy covid",
                this.hierarchyPolygons
              ),
              Geovisto.getGeoDataFactory().geojson(
                "Hierarchy covid Point",
                this.hierarchyPoints
              ),
              Geovisto.getGeoDataFactory().geojson(
                "Hierarchy Connection",
                this.hierarchyConnection
              ),
              Geovisto.getGeoDataFactory().geojson(
                "czech centroids",
                this.centroids2
              )
            ])}
            config={Geovisto.getMapConfigManagerFactory().default(
              this.state.config
            )}
            globals={undefined}
            templates={undefined}
            tools={Geovisto.createMapToolsManager([
              GeovistoSidebarTool.createTool({
                id: "geovisto-tool-sidebar",
            }),
              GeovistoTilesLayerTool.createTool({
                id: "geovisto-tool-layer-map"
              }),
              GeovistoDrawingLayerTool.createTool({
                id: "geovisto-tool-layer-drawing",
            }),
            ])}
          />
        </div>
      </div>
    )
  }
}

export default {
  title: "Demo",
  component: Demo
}

export const GeovistoMap = () => <Demo />
